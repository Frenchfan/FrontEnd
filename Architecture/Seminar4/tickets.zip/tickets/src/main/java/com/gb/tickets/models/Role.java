package com.gb.tickets.models;

public enum Role {
    ADMIN, USER
}
